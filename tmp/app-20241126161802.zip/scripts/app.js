(function() {
  'use strict';

  let client = null;
  let currentTicketId = null;

  // State management
  const state = {
    currentScore: 0,
    scoreThresholds: [23, 36, 54, 68, 85],
    currentThresholdIndex: 0,
    addedBulletPoints: new Set(),
    riskThreshold: 85,
    initialIdentityChecksAdded: false,
    lastProcessedMessage: null
  };

  // Risk assessment triggers
  const triggers = {
    identity: [
      { phrase: "don't have it handy", text: "Unable to Provide Order Information", color: "text-yellow-500", score: 23 },
      { phrase: "can't you find it", text: "Avoidance of Order Verification Process Detected: Medium", color: "text-yellow-500", score: 36 }
    ],
    conversation: [
      { phrase: "rush", text: "Urgency Detected: High", color: "text-red-500", score: 36, additionalPoints: [
          { text: "Story Fabrication: Similar to Past Fraudulent Scripts", color: "text-red-500" }
        ]
      },
      { phrase: "chargeback", text: "Threatening Language: High (Related to Chargebacks)", color: "text-red-500", score: 68, additionalPoints: [
          { text: "Excessive Knowledge of Chargeback Knowledge consistent with Past Fraudulent Claims", color: "text-red-500" }
        ]
      },
      { phrase: "fair credit billing act", text: "Excessive Knowledge of Chargebacks", color: "text-red-500", score: 85 }
    ],
    delivery: [
      { phrase: "impossible", text: "Package was delivered. Proven by Photo Proof of Delivery", color: "text-yellow-500", score: 54 },
      { phrase: "nothing came", text: "Did Not Arrive Claims Not Supported by Tracking Evidence", color: "text-red-500", score: 36 }
    ]
  };

  // Initialize when DOM is ready
  async function init() {
    try {
      client = await ZAFClient.init();
      console.log('ZAF Client initialized');

      // Get current ticket context
      const context = await client.context();
      console.log('App context:', context);
      currentTicketId = context.ticketId;

      // Set up ticket conversation monitoring
      client.on('ticket.conversation.changed', handleConversationChange);
      client.on('comment.created', handleNewComment);

      // Get initial ticket data
      const ticketData = await client.get('ticket');
      console.log('Initial ticket data:', ticketData);

      // Get existing comments
      const comments = await client.get('ticket.comments');
      console.log('Existing comments:', comments);

      if (comments && comments.length > 0) {
        comments.forEach(analyzeComment);
      }

      // Enable debug panel
      document.getElementById('debugPanel').style.display = 'block';
      updateDebugStatus('App initialized successfully');

    } catch (error) {
      console.error('Initialization failed:', error);
      updateDebugStatus('Failed to initialize: ' + error.message);
    }
  }

  async function handleConversationChange(data) {
    console.log('Conversation changed:', data);
    try {
      const comments = await client.get('ticket.comments');
      const newComments = comments.filter(comment => 
        !state.lastProcessedMessage || new Date(comment.created_at) > new Date(state.lastProcessedMessage)
      );

      newComments.forEach(analyzeComment);
      
      if (newComments.length > 0) {
        state.lastProcessedMessage = newComments[newComments.length - 1].created_at;
      }
    } catch (error) {
      console.error('Error handling conversation change:', error);
    }
  }

  async function handleNewComment(data) {
    console.log('New comment created:', data);
    try {
      const comment = await client.get(`ticket.comments.${data.commentId}`);
      analyzeComment(comment);
    } catch (error) {
      console.error('Error handling new comment:', error);
    }
  }

  function analyzeComment(comment) {
    if (!comment || !comment.value) {
      console.log('Invalid comment data:', comment);
      return;
    }

    console.log('Analyzing comment:', comment);
    const text = comment.value.toLowerCase();

    Object.entries(triggers).forEach(([category, triggerList]) => {
      triggerList.forEach(trigger => {
        if (text.includes(trigger.phrase)) {
          console.log('Trigger matched:', trigger);
          updateRiskScore(trigger.score);
          addBulletPoint(trigger.text, category, trigger.color);

          if (trigger.additionalPoints) {
            trigger.additionalPoints.forEach(point => {
              addBulletPoint(point.text, category, point.color);
            });
          }
        }
      });
    });
  }

  async function updateRiskScore(score) {
    state.currentScore = Math.min(100, state.currentScore + score);
    updateRiskMeter(state.currentScore);
    await saveState('currentScore', state.currentScore);
    console.log('Risk score updated:', state.currentScore);
  }

  function updateRiskMeter(score) {
    const meterValue = document.querySelector('.meter-value');
    const scoreText = document.querySelector('.score-value');
    const riskText = document.querySelector('.risk-text');

    if (!meterValue || !scoreText) {
      console.error('Required DOM elements not found for risk meter');
      return;
    }

    const circumference = 2 * Math.PI * 90;
    const offset = circumference - (score / 100) * circumference;
    meterValue.style.strokeDasharray = `${circumference} ${circumference}`;
    meterValue.style.strokeDashoffset = offset;

    scoreText.textContent = `${score}%`;

    if (riskText) {
      let riskLevel, color;
      if (score >= 75) {
        riskLevel = 'Severe Risk';
        color = 'var(--danger-color)';
      } else if (score >= 50) {
        riskLevel = 'High Risk';
        color = 'var(--warning-color)';
      } else if (score >= 25) {
        riskLevel = 'Medium Risk';
        color = 'var(--warning-color)';
      } else {
        riskLevel = 'Low Risk';
        color = 'var(--success-color)';
      }
      riskText.textContent = riskLevel;
      riskText.setAttribute('fill', color);
      meterValue.style.stroke = color;
    }
  }

  function addBulletPoint(text, section, color) {
    const sectionElement = document.getElementById(`${section}-section`);
    if (!sectionElement) {
      console.error(`Section element not found: ${section}-section`);
      return;
    }

    const ul = sectionElement.querySelector('ul');
    if (!ul) {
      console.error('Bullet list not found in section:', section);
      return;
    }

    if (state.addedBulletPoints.has(text)) {
      console.log('Bullet point already exists:', text);
      return;
    }
    
    state.addedBulletPoints.add(text);

    const li = document.createElement('li');
    li.className = `bullet-point ${color}`;
    li.textContent = text;
    ul.appendChild(li);

    requestAnimationFrame(() => {
      li.classList.add('show');
    });

    console.log(`Added bullet point to ${section}:`, text);
    debugLog(`Added ${section} bullet point: ${text}`);
  }

  async function saveState(key, value) {
    try {
      const metadata = await client.metadata();
      await client.set(`ticket.customField:${metadata.appId}_${key}`, value);
    } catch (error) {
      console.error('Error saving state:', error);
      debugLog('State save error: ' + error.message);
    }
  }

  function updateDebugStatus(status) {
    const statusElement = document.getElementById('widgetStatus');
    if (statusElement) {
      statusElement.textContent = status;
    }
    debugLog(status);
  }

  function debugLog(message, level = 'info') {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    
    switch(level) {
      case 'error':
        console.error(logEntry);
        break;
      case 'warn':
        console.warn(logEntry);
        break;
      default:
        console.log(logEntry);
    }
    
    const debugLog = document.getElementById('debugLog');
    if (debugLog) {
      const logElement = document.createElement('div');
      logElement.className = `debug-log debug-${level}`;
      logElement.textContent = logEntry;
      debugLog.insertBefore(logElement, debugLog.firstChild);
      
      while (debugLog.children.length > 50) {
        debugLog.removeChild(debugLog.lastChild);
      }
    }
  }

  async function logDebugInfo() {
    try {
      const metadata = await client.metadata();
      const context = await client.context();
      
      debugLog('App Metadata: ' + JSON.stringify(metadata));
      debugLog('App Context: ' + JSON.stringify(context));
      debugLog('Current Location: ' + window.location.href);
      debugLog('User Agent: ' + navigator.userAgent);
    } catch (error) {
      console.error('Error logging debug info:', error);
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();